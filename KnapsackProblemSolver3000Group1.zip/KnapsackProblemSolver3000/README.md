# KnapsackProblemSolver3000
There is a build of the project in bin > release > net6.0
launch the .exe
good luck